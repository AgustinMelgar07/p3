<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Lectores</title>
</head>
<body>
    <h1>Registrar Lector</h1>

    <form method="POST" action="<?php echo e(isset($lector) ? route('lectores.update', $lector) : route('lectores.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(isset($lector)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <input type="text" name="nombre" placeholder="Nombre" value="<?php echo e($lector->nombre ?? ''); ?>" required>
        <input type="text" name="apellido" placeholder="Apellido" value="<?php echo e($lector->apellido ?? ''); ?>" required>
        <input type="email" name="email" placeholder="Email" value="<?php echo e($lector->email ?? ''); ?>" required>
        <input type="text" name="direccion" placeholder="Dirección" value="<?php echo e($lector->direccion ?? ''); ?>" required>
        <input type="text" name="telefono" placeholder="Teléfono" value="<?php echo e($lector->telefono ?? ''); ?>" required>
        <button type="submit"><?php echo e(isset($lector) ? 'Actualizar' : 'Guardar'); ?></button>
    </form>

    <h2>Lista de Lectores</h2>
    <table border="1" cellpadding="5">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $lectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($l->nombre); ?></td>
                <td><?php echo e($l->apellido); ?></td>
                <td><?php echo e($l->email); ?></td>
                <td><?php echo e($l->direccion); ?></td>
                <td><?php echo e($l->telefono); ?></td>
                <td>
                    <a href="<?php echo e(route('lectores.edit', $l)); ?>">Editar</a>
                    <form method="POST" action="<?php echo e(route('lectores.destroy', $l)); ?>" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" onclick="return confirm('¿Seguro que deseas eliminar este lector?')">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\wamp64\www\rest\API-REST\resources\views/lectores/index.blade.php ENDPATH**/ ?>